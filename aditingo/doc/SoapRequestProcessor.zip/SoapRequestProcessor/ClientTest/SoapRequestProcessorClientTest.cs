using System;
using System.Configuration;
using System.Data.SqlClient;
using log4net;
using log4net.Config;
using NUnit.Framework;

namespace Datran.StormPost.SoapRequestProcessor.Tests {
	[TestFixture]
	public class SoapRequestProcessorClientTest {
		private static readonly ILog _log = LogManager.GetLogger(typeof (SoapRequestProcessorClientTest));

		private int _brandID;
		private int _campaignID;
		private int _facebookApplicationID;
		private SoapRequestProcessorService _client;

		private const String TRACKTYPE_NONE = "NONE";
		private const String STATUS_NEW = "NEW";
		private const String PART_NOTIFICATION = "NOTIFICATION";

		[TestFixtureSetUp]
		public void SetUp() {
			XmlConfigurator.Configure();
			string serviceURL = ConfigurationManager.AppSettings["webservice.url"];
			string username = ConfigurationManager.AppSettings["webservice.username"];
			string password = ConfigurationManager.AppSettings["webservice.password"];
			_client = GetTestServiceInstance(serviceURL, username, password);

			//must be valid IDs in the database that the client is pointing at
			_brandID = int.Parse(ConfigurationManager.AppSettings["unittest.brandid"]);
			_campaignID = int.Parse(ConfigurationManager.AppSettings["unittest.campaignid"]);
			_facebookApplicationID = int.Parse(ConfigurationManager.AppSettings["unittest.facebookapplicationid"]);

			SetupUnitTestDatabase();
		}

		[TestFixtureTearDown]
		public void TearDown() {
			_client.Dispose();
		}

		private static SoapRequestProcessorService GetTestServiceInstance(string serviceURL, string username, string password) {
			SoapRequestProcessorService client = new SoapRequestProcessorService();

			client.Url = serviceURL;
			client.authenticationValue = new authentication();
			client.authenticationValue.username = username;
			client.authenticationValue.password = password;

			return client;
		}

		private static void SetupUnitTestDatabase() {
			string connectionString = ConfigurationManager.AppSettings["unittest.connectionstring"];
			using (SqlConnection connection = new SqlConnection(connectionString)) {
				connection.Open();
				DatabaseWorkHook(connection);
				connection.Close();
			}
		}

		private static void DatabaseWorkHook(SqlConnection connection) {
			// using the connection, create SqlCommands and insert/update records into the unit test database...
			return;
		}

		[Test]
		public void CreateEmailMailingTest() {
			Mailing mailing = new Mailing();
			mailing.title = ".NET client unit test -- Mailing Title";
			mailing.brandID = _brandID;
			mailing.campaignID = _campaignID;
			mailing.trackType = TRACKTYPE_NONE;
			mailing.openTrackType = TRACKTYPE_NONE;
			mailing.clickStreamType = TRACKTYPE_NONE;

			EmailContent emailContent = new EmailContent();
			emailContent.htmlContent = ".NET client unit test -- HTML Content";
			emailContent.subject = ".NET client unit test -- Subject";
			emailContent.fromEmail = "fromEmail@datranmedia.com";
			emailContent.toEmail = "toEmail@datranmedia.com";

			String mailingStatus = string.Empty;

			try {
				int mailingID = _client.createEmailMailing(mailing, emailContent);
				mailingStatus = _client.getMailingStatus(mailingID);
			} catch (Exception ex) {
				_log.Error("Error in CreateEmailMailingTest.", ex);
			}

			Assert.That(mailingStatus.Equals(STATUS_NEW));
		}

		[Test]
		public void CreateFacebookMailingTest() {
			Mailing mailing = new Mailing();
			mailing.title = ".NET client unit test -- Mailing Title";
			mailing.brandID = _facebookApplicationID;
			mailing.campaignID = _campaignID;
			mailing.trackType = TRACKTYPE_NONE;
			mailing.openTrackType = TRACKTYPE_NONE;
			mailing.clickStreamType = TRACKTYPE_NONE;
			FacebookContent content = new FacebookContent();
			content.body = ".NET client unit test -- Facebook Body";
			content.title = ".NET client unit test -- Facebook Title";
			content.type = PART_NOTIFICATION;

			String mailingStatus = string.Empty;
			try {
				int mailingID = _client.createFacebookMailing(mailing, content);
				mailingStatus = _client.getMailingStatus(mailingID);
			} catch (Exception ex) {
				_log.Error("Error in CreateFacebookMailingTest.", ex);
			}

			Assert.That(mailingStatus.Equals(STATUS_NEW));
		}

		[Test]
		public void CreateRecipientTest() {
			Random rng = new Random();
			String address = "unittest@datranmedia.com";
			Recipient recipient = new Recipient();
			//if the recip already exists, add a random digit and try again
			while (true) {
				try {
					recipient.address = address;
					_client.createRecipient(recipient);
					break;
				} catch (Exception e) {
					if (e.Message.Contains("Recipient already exists")) {
						address = rng.Next() + address;
					} else {
						break;
					}
				}
			}

			Recipient created = _client.getRecipientByAddress(address);
			Assert.That(created.address.Equals(recipient.address), "Failed to get recip with address we created");

			ListSubscription[] subscriptions = _client.getRecipientSubscriptions(created.recipID.Value);
			foreach (ListSubscription subscription in subscriptions) {
				_client.unsubscribeFromList(subscription.listID.Value, created.recipID.Value, 0);
			}
			ListSubscription[] newSubscriptions = _client.getRecipientSubscriptions(created.recipID.Value);
			Assert.That(newSubscriptions.Length == 0, "Unsubscribe from list failed");

			foreach (ListSubscription subscription in subscriptions) {
				_client.subscribeToList(subscription.listID.Value, created.recipID.Value, false, "soap", 0);
			}
			ListSubscription[] subscribeSubscriptions = _client.getRecipientSubscriptions(created.recipID.Value);
			Assert.That(subscribeSubscriptions.Length == subscriptions.Length, "Subscribe to list failed");

			created.comment = "new comment";
			_client.updateRecipient(created);
			Recipient updated = _client.getRecipientByAddress(address);
			Assert.That(updated.comment.Equals(created.comment));
		}


		[Test]
		public void DetailedMailingReportTest() {
			Mailing mailing = new Mailing();
			mailing.title = ".NET client unit test -- Mailing Title";
			mailing.brandID = _brandID;
			mailing.campaignID = _campaignID;
			mailing.trackType = TRACKTYPE_NONE;
			mailing.openTrackType = TRACKTYPE_NONE;
			mailing.clickStreamType = TRACKTYPE_NONE;

			EmailContent emailContent = new EmailContent();
			emailContent.htmlContent = ".NET client unit test -- HTML Content";
			emailContent.subject = ".NET client unit test -- Subject";
			emailContent.fromEmail = "fromEmail@datranmedia.com";
			emailContent.toEmail = "toEmail@datranmedia.com";

			String mailingStatus = string.Empty;

			int mailingID = 0;
			try {
				mailingID = _client.createEmailMailing(mailing, emailContent);
				mailingStatus = _client.getMailingStatus(mailingID);
			} catch (Exception ex) {
				_log.Error("Error in CreateEmailMailingTest.", ex);
			}

			Assert.That(mailingStatus.Equals(STATUS_NEW));
			Assert.That(mailingID != 0, "MailingID of zero retrieved from the database.");

			DetailedMailingReport dmr = _client.getDetailedMailingReport(mailingID);
			Assert.That(dmr != null);
			Assert.That(dmr.mailingTitle.Equals(mailing.title));
			Assert.That(dmr.mailingSubject.Equals(emailContent.subject));
			Assert.That(dmr.mailingStatus.Equals(mailingStatus));
		}

		[Test]
		public void GetDetailedMailingReportTest2() {
			string connectionString = ConfigurationManager.AppSettings["unittest.connectionstring"];
			int existingMailingID = int.Parse(ConfigurationManager.AppSettings["unittesting.existingmailingid"]);
			using (SqlConnection connection = new SqlConnection(connectionString)) {
				connection.Open();
				using (SqlCommand command = connection.CreateCommand()) {
					command.CommandText = "UPDATE Mailings SET Archived = 1 WHERE MailingID = " + existingMailingID;
					command.ExecuteNonQuery();

					command.CommandText = "UPDATE MailingStatistics SET " +
					                      "Sent = 100, " +
					                      "Failed = 100, " +
					                      "Suppressed = 100, " +
					                      "HardBounces = 100, " +
					                      "SoftBounces = 100, " +
					                      "BlockBounces = 100, " +
					                      "Unsubs = 100 WHERE MailingID = " +
					                      existingMailingID;

					command.ExecuteNonQuery();
				}
				connection.Close();
			}
			DetailedMailingReport dmr = _client.getDetailedMailingReport(existingMailingID);
			Assert.That(dmr != null);
			Assert.That(dmr.deliveredCount == 100);
			Assert.That(dmr.failedCount == 100);
			Assert.That(dmr.blockedCount == 100);
			Assert.That(dmr.softCount == 100);
			Assert.That(dmr.hardCount == 100);
			Assert.That(dmr.unsubscribeResponsesCount == 100);
		}

		[Test]
		public void GetListsTest() {
			List list = new List();
			List[] lists = _client.getLists(list);
			Assert.That(lists != null);
			Assert.That(lists.Length > 0);
		}

		[Test]
		public void GetListTest() {
			List list = null;
			int counterListID = 0;
			for (int i = 0; i < 50; ++i) {
				counterListID = i;
				try {
					list = _client.getList(i);
					if (list != null) {
						_log.InfoFormat("Found a list with ID: {0}", i);
						break;
					}
				} catch (Exception ex) {
					// Couldn't find a list with that listID
				}
			}
			if (list != null) Assert.That(list.listID == counterListID);
		}

		[Test]
		public void GetVersionTest() {
			String compatibilityVersion = ConfigurationManager.AppSettings["compatibility.version"];
			String version = string.Empty;
			try {
				version = _client.getVersion();
			} catch (Exception ex) {
				_log.Error("Error in GetVersionTest.", ex);
			}

			string testCompatVersion = version.Substring(0, 3); // should be something like "5.2";
			_log.InfoFormat("Version found was: {0}", testCompatVersion);
			Assert.That(version != null);
			Assert.That(version.CompareTo(testCompatVersion) > 0, "Version found was: " + version);
		}

		[Test]
		public void SendMessageFromTemplateTest() {
			int sendTemplateID = int.Parse(ConfigurationManager.AppSettings["unittest.sendtemplateid"]);
			String[] nameValuePairs = {"name1=value1"};
			_client.sendMessageFromTemplate(sendTemplateID, "unittest@datranmedia.com", nameValuePairs);
			Assert.That(true);
		}
	}
}